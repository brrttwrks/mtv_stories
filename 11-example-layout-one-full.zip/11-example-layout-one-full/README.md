# One-column full-width responsive layout

[One-column full-width responsive layout](https://github.com/russmaxdesign/example-layout-one-full) is a basic responsive HTML template.

## File structure

[One-column full-width responsive layout](https://github.com/russmaxdesign/example-layout-one-full) uses the following file structure:

	assets/
		css/
			styles.css
		img/
			apple-touch-icon.png
	favicon.ico
	index.html
	licence.md
	readme.md

[One-column full-width responsive layout](https://github.com/russmaxdesign/example-layout-one-full) was created by [Russ Weakley](https://twitter.com/russmaxdesign), [Max Design](http://maxdesign.com.au/). Copyright 2015 Max Design. See LICENCE.md for full details.